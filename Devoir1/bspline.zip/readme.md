# introduction :
un un dessin d'un Oméga est déjà present dans dans le script python mais pour plot les Bspline d'un autre dessin rien de plus simple : il suffit de run la fonction `main(n,data)` ou n est le nombres de points de contrôle et data est un tableau de taille n*2 contenant les coordonnées des points du dessin.
des print ont été placé dans le main et dans les plots pour faciliter la compréhension du correcteur il suffit de les décommenter.

# how to run :    
```bash
python Bspline.py
```


# rapport :
[lien rapport ](https://www.overleaf.com/project/65c6510969cb383977de0096)

